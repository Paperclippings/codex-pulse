// ../../node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffered += decoder.decode(value, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message) {
    const chunk = this.encoder.encode(`${JSON.stringify(message)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// ../../node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime = globalThis.Deno;
  if (!runtime) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime.stdin.readable,
    writable: runtime.stdout.writable,
    exit: (code) => runtime.exit(code)
  };
}

// ../../node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message) {
  return message.encoding === "json" ? message.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin1 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin1 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin1);
}
function fromBase64(data) {
  const latin1 = atob(data);
  const bytes = new Uint8Array(latin1.length);
  for (let i = 0; i < latin1.length; i++)
    bytes[i] = latin1.charCodeAt(i);
  return bytes;
}
function intoWire(message) {
  if (typeof message === "string")
    return { encoding: "text", data: message };
  if (message instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message) };
  if (message.encoding === "binary")
    return { encoding: "binary", data: toBase64(message.data) };
  return message;
}
function fromWire(message) {
  if (message.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message.data) };
  return message;
}

// ../../node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// ../../node_modules/@bridgething/extension/dist/runtime.js
function describe(value) {
  if (typeof value === "string")
    return value;
  if (value instanceof Error)
    return value.stack ?? `${value.name}: ${value.message}`;
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime) {
    this.id = id;
    this.runtime = runtime;
  }
  send(message) {
    this.runtime.forward(this.id, message);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message) {
    this.forward(void 0, message);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value) => value === null ? void 0 : value),
    set: (key, value) => this.request((id) => ({ t: "kv.set", id, key, value })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value) => value ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value) => String(value))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message) {
    const wire = intoWire(message);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message = this.parse(line);
        if (!message)
          continue;
        if (message.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message) {
    switch (message.t) {
      case "hello": {
        this.helloApi = message.api;
        this.helloWebapp = message.webapp;
        this.helloDataDir = message.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message.device);
        device.name = message.name;
        device.config = { ...message.config };
        device.active = message.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message.device);
        device.active = message.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message.device);
        const forwarded = this.guard(() => fromWire(message.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message.device);
        const next = { ...device.config };
        if (message.value === null)
          delete next[message.key];
        else
          next[message.key] = message.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message.key, message.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message.id);
        if (!waiting)
          return;
        this.pending.delete(message.id);
        if (message.ok)
          waiting.resolve(message.value);
        else
          waiting.reject(new ExtensionError(message.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run) {
    try {
      return run();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message) {
    this.writer.write(message).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// ../../node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// extension/main.ts
var home = Deno.env.get("HOME");
if (!home) throw new Error("HOME is unavailable");
var codexRoot = `${home}/.codex`;
var codexBinary = "/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex";
async function sqlite(path, query) {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const output = await new Deno.Command("/usr/bin/sqlite3", {
        args: ["-readonly", "-json", path, query],
        stdout: "piped",
        stderr: "piped"
      }).output();
      if (!output.success) throw new Error(`${path}: ${new TextDecoder().decode(output.stderr).trim() || "sqlite3 failed"}`);
      const body = new TextDecoder().decode(output.stdout).trim();
      return body ? JSON.parse(body) : [];
    } catch (error) {
      if (attempt === 2) throw error;
      await new Promise((resolve) => setTimeout(resolve, 150 * (attempt + 1)));
    }
  }
  return [];
}
async function readThreads() {
  const [rows, turns, questions] = await Promise.all([
    sqlite(codexRoot + "/state_5.sqlite", "SELECT id, COALESCE(NULLIF(name, ''), NULLIF(title, ''), 'Untitled') AS title, updated_at AS updatedAt FROM threads WHERE archived = 0 AND thread_source = 'user' ORDER BY updated_at DESC LIMIT 1000"),
    sqlite(codexRoot + "/thread_history_1.sqlite", "SELECT t.thread_id AS id, t.status FROM thread_turns t JOIN (SELECT thread_id, MAX(rollout_ordinal) AS last_ordinal FROM thread_turns GROUP BY thread_id) latest ON latest.thread_id = t.thread_id AND latest.last_ordinal = t.rollout_ordinal"),
    sqlite(codexRoot + "/thread_history_1.sqlite", "SELECT q.thread_id AS id FROM thread_items q WHERE q.item_type = 'agentMessage' AND json_array_length(json_extract(q.item_json, '$.questions')) > 0 AND q.created_at_ms > COALESCE((SELECT MAX(u.created_at_ms) FROM thread_items u WHERE u.thread_id = q.thread_id AND u.item_type = 'userMessage'), 0) GROUP BY q.thread_id")
  ]);
  const activeIds = new Set(rows.map((row) => String(row.id)));
  const waitingIds = new Set(questions.map((row) => String(row.id)));
  const stateById = new Map(turns.map((row) => [String(row.id), String(row.status)]));
  const toThread = (row) => ({
    id: String(row.id),
    title: String(row.title),
    updatedAt: Number(row.updatedAt),
    state: stateById.get(String(row.id)) === "inProgress" ? "running" : "idle",
    needsYou: waitingIds.has(String(row.id))
  });
  const threads = rows.slice(0, 12).map(toThread);
  const needsYouThreads = rows.filter((row) => waitingIds.has(String(row.id))).slice(0, 30).map(toThread);
  return { threads, needsYouThreads, attention: [...waitingIds].filter((id) => activeIds.has(id)).length };
}
var tokenFileCache = /* @__PURE__ */ new Map();
async function tokenRecords(path) {
  const stat = await Deno.stat(path);
  const cached = tokenFileCache.get(path);
  const modified = stat.mtime?.getTime() ?? 0;
  if (cached?.modified === modified && cached.size === stat.size) return cached.records;
  const records = [];
  const file = await Deno.open(path, { read: true });
  try {
    const reader = file.readable.pipeThrough(new TextDecoderStream()).getReader();
    let pending = "";
    for (; ; ) {
      const { value, done } = await reader.read();
      if (done) break;
      pending += value;
      let end;
      while ((end = pending.indexOf("\n")) >= 0) {
        const line = pending.slice(0, end);
        pending = pending.slice(end + 1);
        if (!line.includes('"type":"token_usage_record"')) continue;
        try {
          const record = JSON.parse(line);
          const usage = record.payload?.usage;
          if (usage && Number.isFinite(usage.total_tokens)) records.push({
            timestamp: record.timestamp,
            input: usage.input_tokens ?? 0,
            output: usage.output_tokens ?? 0,
            total: usage.total_tokens ?? 0
          });
        } catch {
        }
      }
    }
  } finally {
    try {
      file.close();
    } catch {
    }
  }
  tokenFileCache.set(path, { modified, size: stat.size, records });
  return records;
}
async function readTokenDays() {
  const days = Array.from({ length: 3 }, (_, offset) => {
    const date = /* @__PURE__ */ new Date();
    date.setHours(12, 0, 0, 0);
    date.setDate(date.getDate() - offset);
    return date.toLocaleDateString("en-CA");
  }).reverse();
  const totals = new Map(days.map((day) => [day, { day, inputTokens: 0, outputTokens: 0, totalTokens: 0 }]));
  const utcDates = /* @__PURE__ */ new Set();
  for (let offset = 0; offset < 5; offset++) {
    const date = new Date(Date.now() - offset * 864e5);
    utcDates.add(`${date.getUTCFullYear()}/${String(date.getUTCMonth() + 1).padStart(2, "0")}/${String(date.getUTCDate()).padStart(2, "0")}`);
  }
  for (const date of utcDates) {
    const directory = `${codexRoot}/sessions/${date}`;
    try {
      for await (const entry of Deno.readDir(directory)) {
        if (!entry.isFile || !entry.name.endsWith(".jsonl")) continue;
        for (const record of await tokenRecords(`${directory}/${entry.name}`)) {
          const day = new Date(record.timestamp).toLocaleDateString("en-CA");
          const total = totals.get(day);
          if (!total) continue;
          total.inputTokens += record.input;
          total.outputTokens += record.output;
          total.totalTokens += record.total;
        }
      }
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) throw error;
    }
  }
  return days.map((day) => totals.get(day));
}
function parseWindow(value) {
  if (!value || typeof value !== "object") return null;
  const window = value;
  if (typeof window.usedPercent !== "number") return null;
  return {
    usedPercent: window.usedPercent,
    windowDurationMins: Number(window.windowDurationMins),
    resetsAt: Number(window.resetsAt)
  };
}
async function readUsage() {
  const child = new Deno.Command(codexBinary, {
    args: ["app-server", "--stdio"],
    stdin: "piped",
    stdout: "piped",
    stderr: "null"
  }).spawn();
  const writer = child.stdin.getWriter();
  const requests = [
    { method: "initialize", id: 1, params: { clientInfo: { name: "codex-pulse", title: "Codex Pulse", version: "0.1.0" } } },
    { method: "initialized", params: {} },
    { method: "account/rateLimits/read", id: 2 }
  ];
  await writer.write(new TextEncoder().encode(requests.map((value) => JSON.stringify(value)).join("\n") + "\n"));
  const reader = child.stdout.getReader();
  let pending = "";
  try {
    const deadline = Date.now() + 1e4;
    while (Date.now() < deadline) {
      const read = await Promise.race([
        reader.read(),
        new Promise((_, reject) => setTimeout(() => reject(new Error("Codex usage request timed out")), Math.max(1, deadline - Date.now())))
      ]);
      if (read.done) break;
      pending += new TextDecoder().decode(read.value);
      while (pending.includes("\n")) {
        const index = pending.indexOf("\n");
        const line = pending.slice(0, index);
        pending = pending.slice(index + 1);
        if (!line.trim()) continue;
        let message;
        try {
          message = JSON.parse(line);
        } catch {
          continue;
        }
        if (message.id !== 2) continue;
        if (message.error) throw new Error(JSON.stringify(message.error));
        const result = message.result;
        const byId = result.rateLimitsByLimitId;
        const limits = byId?.codex ?? result.rateLimits;
        return { primary: parseWindow(limits?.primary), secondary: parseWindow(limits?.secondary) };
      }
    }
    throw new Error("Codex usage response unavailable");
  } finally {
    try {
      child.kill();
    } catch {
    }
    try {
      await writer.close();
    } catch {
    }
  }
}
var timer;
var retryTimer;
defineExtension({
  start(ctx) {
    let latest;
    let lastGoodThreads;
    let updating = false;
    let retryDelayMs = 5e3;
    async function update() {
      if (updating) return;
      updating = true;
      try {
        const [threads, usage, tokenDays] = await Promise.allSettled([readThreads(), readUsage(), readTokenDays()]);
        if (threads.status === "fulfilled") {
          lastGoodThreads = threads.value;
          clearTimeout(retryTimer);
          retryTimer = void 0;
          retryDelayMs = 5e3;
        } else {
          ctx.log.warn(`Codex history read failed; retrying: ${String(threads.reason)}`);
          if (retryTimer === void 0) {
            const delay = retryDelayMs;
            retryDelayMs = Math.min(retryDelayMs * 2, 6e4);
            retryTimer = setTimeout(() => {
              retryTimer = void 0;
              void update();
            }, delay);
          }
        }
        const threadData = threads.status === "fulfilled" ? threads.value : lastGoodThreads;
        latest = {
          type: "snapshot",
          fetchedAt: Date.now(),
          threads: threadData?.threads ?? [],
          needsYouThreads: threadData?.needsYouThreads ?? [],
          usage: usage.status === "fulfilled" ? usage.value : { primary: null, secondary: null, error: String(usage.reason) },
          tokenDays: tokenDays.status === "fulfilled" ? tokenDays.value : [],
          // Pending prompts are inferred from local, unanswered question items.
          attention: threadData?.attention ?? null,
          error: threads.status === "rejected" ? "Codex history is temporarily unavailable. Retrying\u2026" : void 0
        };
        ctx.broadcast(json(latest));
      } finally {
        updating = false;
      }
    }
    ctx.on("device", (event) => {
      if (event.type !== "connected" && event.type !== "active") return;
      if (latest) event.device.send(json(latest));
      void update();
    });
    ctx.on("message", (device, message) => {
      const payload = asJson(message);
      if (payload?.type === "refresh") {
        if (latest) device.send(json(latest));
        void update();
      }
    });
    timer = setInterval(() => void update(), 6e4);
    void update();
    ctx.log.info("Codex Pulse started");
  },
  stop() {
    clearInterval(timer);
    clearTimeout(retryTimer);
    retryTimer = void 0;
  }
});
